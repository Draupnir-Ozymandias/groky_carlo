"""Branching long/short recovery lab. See PROJECT_BRIEF.md."""

from __future__ import annotations

import argparse
import json
import math
import random
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"


@dataclass
class Lineage:
    stake: float = 0.0
    debt: float = 0.0
    streak: int = 0
    depth: int = 0
    active: bool = False


@dataclass
class PathResult:
    terminal: float
    ruined: bool
    ruin_step: int | None
    max_drawdown: float
    max_depth: int
    resets: int
    steps: int
    trace: list[dict] = field(default_factory=list)


def _kelly_fraction(p: float, scale: float) -> float:
    return max(0.0, (2.0 * p - 1.0) * scale)


def run_pure_martingale(outcomes: list[int], capital: float, base: float, p: float) -> PathResult:
    cash = capital
    peak = capital
    max_dd = 0.0
    side_long = p >= 0.5
    stake = base
    for step, up in enumerate(outcomes, start=1):
        if stake > cash + 1e-9:
            return PathResult(cash, True, step, max_dd, 0, 0, step - 1)
        won = (up == 1 and side_long) or (up == 0 and not side_long)
        cash += stake if won else -stake
        peak = max(peak, cash)
        max_dd = max(max_dd, (peak - cash) / peak if peak else 0.0)
        stake = base if won else stake * 2.0
        if cash < base:
            return PathResult(cash, True, step, max_dd, 0, 0, step)
    return PathResult(cash, False, None, max_dd, 0, 0, len(outcomes))


def run_kelly(outcomes: list[int], capital: float, base: float, p: float, kelly_scale: float) -> PathResult:
    cash = capital
    peak = capital
    max_dd = 0.0
    f = _kelly_fraction(p, kelly_scale)
    side_long = p >= 0.5
    for step, up in enumerate(outcomes, start=1):
        stake = cash * f if f > 0 else base
        stake = min(stake, cash)
        if stake < 1e-9:
            return PathResult(cash, True, step, max_dd, 0, 0, step - 1)
        won = (up == 1 and side_long) or (up == 0 and not side_long)
        cash += stake if won else -stake
        peak = max(peak, cash)
        max_dd = max(max_dd, (peak - cash) / peak if peak else 0.0)
        if cash < 1e-6:
            return PathResult(0.0, True, step, max_dd, 0, 0, step)
    return PathResult(cash, False, None, max_dd, 0, 0, len(outcomes))


def run_paroli(outcomes: list[int], capital: float, base: float, p: float) -> PathResult:
    cash = capital
    peak = capital
    max_dd = 0.0
    side_long = p >= 0.5
    stake = base
    wins = 0
    for step, up in enumerate(outcomes, start=1):
        if stake > cash + 1e-9:
            return PathResult(cash, True, step, max_dd, 0, 0, step - 1)
        won = (up == 1 and side_long) or (up == 0 and not side_long)
        cash += stake if won else -stake
        peak = max(peak, cash)
        max_dd = max(max_dd, (peak - cash) / peak if peak else 0.0)
        if won:
            wins += 1
            stake = stake * 2.0 if wins < 3 else base
            if wins >= 3:
                wins = 0
                stake = base
        else:
            wins = 0
            stake = base
        if cash < base:
            return PathResult(cash, True, step, max_dd, 0, 0, step)
    return PathResult(cash, False, None, max_dd, 0, 0, len(outcomes))


def run_branching(
    outcomes: list[int],
    capital: float,
    base: float,
    p: float,
    alpha: float,
    k_trigger: int,
    tau: float,
    d_max: int,
    risk_cap: float,
    keep_trace: bool,
) -> PathResult:
    cash = capital
    peak = capital
    max_dd = 0.0
    max_depth = 0
    resets = 0
    long = Lineage()
    short = Lineage()
    favored_long = p >= 0.5
    if abs(p - 0.5) < 1e-12:
        long.stake = base / 2.0
        short.stake = base / 2.0
        long.active = short.active = True
    elif favored_long:
        long.stake = base
        long.active = True
    else:
        short.stake = base
        short.active = True
    trace: list[dict] = []

    def place(line: Lineage, amount: float, depth: int) -> float:
        nonlocal cash
        amount = max(0.0, amount)
        room = risk_cap * capital - (long.stake + short.stake - line.stake)
        amount = min(amount, max(0.0, room), cash)
        line.stake = amount
        line.active = amount > 1e-9
        line.depth = depth if line.active else 0
        return amount

    for step, up in enumerate(outcomes, start=1):
        open_stake = long.stake + short.stake
        if open_stake < 1e-9 or open_stake > cash + 1e-6:
            return PathResult(cash, True, step, max_dd, max_depth, resets, step - 1, trace)

        long_stake, short_stake = long.stake, short.stake
        if up == 1:
            cash += long_stake - short_stake
            long.debt = max(0.0, long.debt - long_stake)
            short.debt += short_stake
            long.streak = 0
            short.streak += 1 if short_stake > 0 else short.streak
        else:
            cash += short_stake - long_stake
            short.debt = max(0.0, short.debt - short_stake)
            long.debt += long_stake
            short.streak = 0
            long.streak += 1 if long_stake > 0 else long.streak

        reset_flag = 0
        for line in (long, short):
            if line.debt <= 1e-9 and line.active:
                line.debt = 0.0
                line.streak = 0
                line.depth = 0
                line.stake = 0.0
                line.active = False
                resets += 1
                reset_flag = 1

        peak = max(peak, cash)
        max_dd = max(max_dd, (peak - cash) / peak if peak else 0.0)
        max_depth = max(max_depth, long.depth, short.depth)

        if keep_trace:
            trace.append(
                {
                    "step": step,
                    "outcome": "up" if up == 1 else "down",
                    "cash": round(cash, 6),
                    "long_stake": round(long_stake, 6),
                    "short_stake": round(short_stake, 6),
                    "long_debt": round(long.debt, 6),
                    "short_debt": round(short.debt, 6),
                    "long_depth": long.depth,
                    "short_depth": short.depth,
                    "reset": reset_flag,
                    "ruined": 0,
                }
            )

        # clear placed stakes; recompute next book
        long.stake = 0.0
        short.stake = 0.0

        def recovery(line: Lineage) -> float:
            return max(base, line.debt if line.debt > 0 else base)

        # re-open base if both collapsed
        if long.debt <= 0 and short.debt <= 0:
            if abs(p - 0.5) < 1e-12:
                place(long, base / 2.0, 0)
                place(short, base / 2.0, 0)
            elif favored_long:
                place(long, base, 0)
            else:
                place(short, base, 0)
        else:
            for line, other, depth0 in (
                (long, short, long.depth),
                (short, long, short.depth),
            ):
                if line.debt <= 0 and line.streak == 0:
                    continue
                rec = recovery(line)
                split = line.streak >= k_trigger or line.debt >= tau
                depth = depth0 + 1 if split else depth0
                if split and depth <= d_max:
                    place(line, alpha * rec, depth)
                    place(other, max(other.stake, (1.0 - alpha) * rec), other.depth)
                elif split:
                    place(line, min(rec, base), depth0)
                else:
                    place(line, min(rec, max(base, line.debt)), depth0)

        if long.stake + short.stake < 1e-9 or cash < base:
            return PathResult(cash, True, step, max_dd, max_depth, resets, step, trace)

    return PathResult(cash, False, None, max_dd, max_depth, resets, len(outcomes), trace)


def summarize(name: str, results: list[PathResult], capital: float) -> dict:
    n = len(results)
    terminals = sorted(r.terminal for r in results)
    dds = sorted(r.max_drawdown for r in results)
    ruined = sum(1 for r in results if r.ruined)
    log_floor = 1.0
    logs = [math.log(max(r.terminal, log_floor) / capital) for r in results]
    return {
        "strategy": name,
        "paths": n,
        "ruin_rate": ruined / n,
        "median_terminal": terminals[n // 2],
        "mean_terminal": sum(terminals) / n,
        "frac_above_start": sum(1 for w in terminals if w > capital) / n,
        "median_max_drawdown": dds[n // 2],
        "p95_max_drawdown": dds[min(n - 1, int(0.95 * n))],
        "mean_log_growth": sum(logs) / n,
        "log_floor_unit": log_floor,
        "frac_with_reset": sum(1 for r in results if r.resets > 0) / n,
        "median_max_depth": sorted(r.max_depth for r in results)[n // 2],
    }


def write_trace(path: Path, path_id: int, result: PathResult) -> None:
    lines = ["path_id,step,outcome,cash,long_stake,short_stake,long_debt,short_debt,long_depth,short_depth,reset,ruined"]
    for row in result.trace:
        lines.append(
            f"{path_id},{row['step']},{row['outcome']},{row['cash']},{row['long_stake']},{row['short_stake']},"
            f"{row['long_debt']},{row['short_debt']},{row['long_depth']},{row['short_depth']},{row['reset']},{row['ruined']}"
        )
    path.write_text("\n".join(lines) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Branching recovery Monte Carlo lab")
    parser.add_argument("--paths", type=int, default=2000)
    parser.add_argument("--horizon", type=int, default=500)
    parser.add_argument("--p", type=float, default=0.55)
    parser.add_argument("--capital", type=float, default=1000.0)
    parser.add_argument("--base", type=float, default=1.0)
    parser.add_argument("--alpha", type=float, default=0.70)
    parser.add_argument("--k", type=int, default=2)
    parser.add_argument("--tau", type=float, default=8.0)
    parser.add_argument("--d-max", type=int, default=6)
    parser.add_argument("--risk-cap", type=float, default=0.25)
    parser.add_argument("--kelly-scale", type=float, default=0.5)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--trace-paths", type=int, default=25)
    args = parser.parse_args()

    rng = random.Random(args.seed)
    ensembles = {name: [] for name in ("pure_martingale", "flat_kelly", "paroli", "branching")}
    sample_trace = None
    sample_id = 0

    for i in range(args.paths):
        outcomes = [1 if rng.random() < args.p else 0 for _ in range(args.horizon)]
        ensembles["pure_martingale"].append(run_pure_martingale(outcomes, args.capital, args.base, args.p))
        ensembles["flat_kelly"].append(
            run_kelly(outcomes, args.capital, args.base, args.p, args.kelly_scale)
        )
        ensembles["paroli"].append(run_paroli(outcomes, args.capital, args.base, args.p))
        keep = i < args.trace_paths
        branched = run_branching(
            outcomes,
            args.capital,
            args.base,
            args.p,
            args.alpha,
            args.k,
            args.tau,
            args.d_max,
            args.risk_cap,
            keep,
        )
        ensembles["branching"].append(branched)
        if keep and sample_trace is None and branched.trace:
            sample_trace = branched
            sample_id = i

    summary = {
        "config": vars(args),
        "note": "Branching reshapes path risk. It does not create edge when p <= 0.5 under even money.",
        "strategies": [
            summarize(name, results, args.capital) for name, results in ensembles.items()
        ],
    }
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    if sample_trace is not None:
        write_trace(RESULTS / "trace_sample.csv", sample_id, sample_trace)
    print(json.dumps(summary["strategies"], indent=2))


if __name__ == "__main__":
    main()
