# Monte Carlo research lab

Self-contained brief: [PROJECT_BRIEF.md](PROJECT_BRIEF.md).

This tree is the project root. The requested path `/Users/grok/monte_carlo` does not exist in this environment; copy this folder there if you want that local layout.

## Run

```bash
python src/simulate.py --paths 2000 --horizon 500 --p 0.55 --alpha 0.70 --seed 42
```

Writes `results/summary.json` and `results/trace_sample.csv`.

Default scenario matches the brief: capital 1000, base 1, p = 0.55, alpha = 0.70, k = 2, tau = 8, depth cap 6, risk cap 0.25, seed 42.

The engine compares pure martingale, half-Kelly, Paroli, and the branching long/short recovery rule on paired outcome paths. Branching does not create edge when p ≤ 0.5.
