# Stake and debt updates

Even-money binary outcome. Shared cash \(C\). Lineages \(L\) (long) and \(S\) (short).

## Settlement

Draw \(U_t \in \{\text{up}, \text{down}\}\) with \(P(\text{up}) = p\).

If up:

- \(C \leftarrow C + \text{stake}_L - \text{stake}_S\)
- \(\text{debt}_L \leftarrow \text{debt}_L - \text{stake}_L\)
- \(\text{debt}_S \leftarrow \text{debt}_S + \text{stake}_S\)
- streak\(_L \leftarrow 0\), streak\(_S \leftarrow\) streak\(_S + 1\)

If down, swap the roles of \(L\) and \(S\).

Debt is floored at 0 after a winning settlement only once the win has covered that lineage’s debt. Any excess win remains in shared cash and counts as cycle surplus.

## Collapse

If \(\text{debt}_L \le 0\) after settlement, reset lineage \(L\): stake candidate returns to base \(b\), streak 0, depth 0, and a reset flag is recorded. Same for \(S\).

## Next stake

Let \(S_{\text{rec}}\) be the recovery amount for a lineage that just lost. Default recovery amount is the sum of that lineage’s debt (the amount a single win must cover) , capped by remaining risk budget.

Split when streak \(\ge k\) or debt \(\ge \tau\):

\[
S_{\text{continue}} = \alpha S_{\text{rec}}, \qquad S_{\text{counter}} = (1-\alpha) S_{\text{rec}}
\]

Otherwise the losing lineage’s next stake is \(\min(2 \cdot \text{stake}, S_{\text{rec}})\) and no counter stake is added.

Depth above \(d_{\max}\) suppresses the counter leg.

Risk cap:

\[
\text{stake}_L + \text{stake}_S \le r C_0
\]

and each stake must be \(\le C\) at placement time. Stake that fails either check is reduced to what fits, or set to 0.

## Ruin

If both proposed stakes are 0 and cash \(< b\), the path is ruined.
